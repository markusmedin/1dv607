# Instructions to run the application

If you have a Java IDE installed I recommend you to import this project in it an run it through the IDE, the alternative is to
install Java Runtime and then exectue the Yachtclub.jar, normaly with the following syntax "java -jar Yachtclub.jar"

gson2.8.2 is used in the project and can be downloaded from https://repo1.maven.org/maven2/com/google/code/gson/gson/2.8.2/gson-2.8.2.jar
